start:-
	write("Please Enter your Choice of Days and Cost:\n"),
	write("What is your Days limit:\n"),readint(Day),
	write("What is your Cost limit:\n"),readint(Cost),
	checkpackage(Day,Cost).
checkpackage(Day,Cost):-
	Day > 0, Day < 6, Cost=800, bahamaputra,!;
	Day > 5, Day < 8, Cost=1000, ganges,!;
	Day > 7, Day < 15, Cost=1500, indus,!.

bahamaputra:-
	write("Package suitable to u is Bahamaputra\n").
ganges:-
	write("Package suitable to u is ganges\n").
indus:-
        write("Package suitable to u is indus\n").
goal:-
    start.



