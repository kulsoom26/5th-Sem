start:-
	write("Please Enter your Day and month:\n"),
	write("What is your Birth Day:\n"),read(Day),
	write("What is your Birth month:\n"),read(Month),
	zodiac_sign(Day,Month).
zodiac_sign(Day,Month):-
    Month = 12, Day < 22, sagitarrius,!;
    Month = 12, Day > 22, capricorn,!;
    Month = 1, Day < 20, capricorn,!;
    Month = 1, Day > 20, aquarius,!;
    Month = 2, Day < 19, aquarius,!;
    Month = 2, Day > 19, pisces,!;
    Month = 3, Day < 21, pisces,!;
    Month = 3, Day > 21, aries,!;
    Month = 4, Day < 20, aries,!;
    Month = 4, Day > 20, taurus,!;
    Month = 5, Day < 21, taurus,!;
    Month = 5, Day > 21, gemini,!;
    Month = 6, Day < 21, gemini,!;
    Month = 6, Day > 21, cancer,!;
    Month = 7, Day < 23, cancer,!;
    Month = 7, Day > 23, leo,!;
    Month = 8, Day < 23, leo,!;
    Month = 8, Day > 23, virgo,!;
    Month = 9, Day < 23, virgo,!;
    Month = 9, Day > 23, libra,!;
    Month = 10, Day < 23, libra,!;
    Month = 10, Day > 23, scorpio,!;
    Month = 11, Day < 22, scorpio,!;
    Month = 11, Day > 22, sagitarrius,!.


capricorn:-
	write("Your Star is Capricorn\n").
sagitarrius:-
	write("Your Star is Sagitarrius\n").
aquarius:-
	write("Your Star is Aquarius\n").
pisces:-
	write("Your Star is Pisces\n").
aries:-
	write("Your Star is Aries\n").
taurus:-
	write("Your Star is Taurus\n").
gemini:-
	write("Your Star is Gemini\n").
cancer:-
	write("Your Star is Cancer\n").
leo:-
	write("Your Star is Leo\n").
virgo:-
	write("Your Star is Virgo\n").
libra:-
	write("Your Star is Libra\n").
scorpio:-
	write("Your Star is Scorpio\n").
goal:-
    start.
