#act1
woman(mia).
woman(judy).
woman(yolanda).
playAirGuitar(jody).

#act2
listesnToMusic(mia).
happy(yolanda).
playsAirGuitar(mia):-listensToMusic(mia).
playsAirGuitar(yolanda):-listensToMusic(yolanda).
listensToMusic(yolanda):-happy(yolanda).

#act3
happy(vincent).
listensToMusic(butch).
playsAirGuitar(vincent):-listensToMusic(vincent),happy(vicent).
playsAirGuitar(butch):-happy(butch).
playsirGuitar(butch):-listensToMusic(butch).

#act4
parent(albert,bob).
parent(albert,betsy).
parent(alberr,bill).
#act5
parent(alice,bob).
parent(alice,betsy).
parent(alice,bill).
#act6
parent(bob,carl).
parent(bob,charlie).
#act7
teacher(albert).
teacher(alice).

#act8
get_grandChild:-
    parent(albert,X),
    parent(X,Y),
    write('Alberts grandchild is '),
    write(Y), nl.

#act9
get_grandParent(X,Y):-
    parent(Z,X),
    parent(Y,Z).

#act10
get_grandParent:-
    parent(X,carl),
    parent(X,charlie),
    format('~w ~s grandparent ~n',[X,'is the']).

#act11
stabs(mohsin,ali).
hates(aliRelative,X):-stabs(X,ali).


whatGrade(5):-write('grade is 5').
whatGrade(6):-write('grade is 6').
whatGrade(Other):-
    G is Other - 5,
    format('Grade is ~w', [G]).

