female(kulsoom)
male(kassim).
female(nazama).
male(khurshid).
female(maryam).
male(farid).

parent_of(nazama,kulsoom).
parent_of(nazama,kassim).
parent_of(khurshid,kulsoom).
parent_of(khurshid,kassim).
parent_of(maryam,khurshid).
parent_of(farid,khurshid).

mother_of(nazama,kulsoom):- female(nazama),parent_of(nazama,kulsoom).
father_of(khurshid,kulsoom):- male(khurshid),parent_of(khurshid,kulsoom).
mother_of(nazama,kassim):- female(nazama),parent_of(nazama,kassim).
father_of(khurshid,kassim):- male(khurshid),parent_of(khurshid,kassim).

grandfather_of(farid,kulsoom):-male(farid),father_of(farid,khurshid),father(khurshid,kulsoom).
grandfather_of(farid,kassim):-male(farid),father_of(farid,khurshid),father(khurshid,kassim).
grandmother_of(maryam,kulsoom):-female(maryam),mother_of(maryam,khurshid),father_of(khurshid,kulsoom).grandmother_of(maryam,kassim):-female(maryam),mother_of(maryam,khurshid),father(khurshid,kassim).

sibling_of(kassim,kulsoom) :- father_of(khurshid,kassim),father_of(khurshid,kulsoom).














