parent(albert,bob).
parent(albert,betsy).
parent(albert,bill).

parent(alice,bob).
parent(alice,betsy).
parent(alice,bill).

parent(bob,carl).
parent(bob,charlie).

teacher(albert).
teacher(alice).

getUncle(C,U):-
    parent(P,C),
    parent(G,P),
    parent(G,U),
    not(P=U).
